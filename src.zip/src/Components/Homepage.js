// src/Homepage.js
import React, { useEffect } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import { Link, useNavigate } from "react-router-dom";

const Homepage = () => {
  const { loginWithRedirect, user, isAuthenticated, logout, isLoading } = useAuth0();
  const navigate = useNavigate();

  // Redirect to the dashboard if the user is authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate("/Dashboard");
    }
  }, [isAuthenticated, navigate]);

  // Load the chatbot script
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://www.chatbase.co/embed.min.js";
    script.async = true;
    script.defer = true;
    script.setAttribute("chatbotId", "VjcL9s_DSfBbMyhDcfQYU");
    script.setAttribute("domain", "www.chatbase.co");
    document.body.appendChild(script);

    window.embeddedChatbotConfig = {
      chatbotId: "VjcL9s_DSfBbMyhDcfQYU",
      domain: "www.chatbase.co",
    };

    // Cleanup the script when the component is unmounted
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  if (isLoading) return <div>Loading...</div>;

  return (
    <div>
      <header className="navbar">
        <div className="logo">NOLAN</div>
        <nav className="nav_name">
          <Link to="#about">About Us</Link>
          <Link to="#pricing">Pricing</Link>
          <Link to="#features">Features</Link>
          <Link to="#project">New Project</Link>
          <Link to="#blog">Blog</Link>

          {isAuthenticated ? (
            <>
              <div>Welcome {user?.name}</div>
              <button onClick={() => logout({ logoutParams: { returnTo: window.location.origin } })}>
                Log Out
              </button>
            </>
          ) : (
            <button className="login-btn" onClick={() => loginWithRedirect()}>
              Log in
            </button>
          )}
        </nav>
      </header>
      {/* Nav Bar Ended */}

      <section className="hero-section">
        <div className="hero-text">
          <h1>Bring your film project to life</h1>
          <h3>
            from <span>idea</span> to <span>production</span>
          </h3>
          <a href="/login">
            <button type="button" className="login-btn2">
              <div>Start Creating</div>
            </button>
          </a>
        </div>

        <div className="image-container">
          <img src={"Home_image.png"} alt="Film Production" className="image" />
        </div>
      </section>

      <section className="about-section" id="about">
        <h1>NolanAI is a collaborative film production suite</h1>
        <h2>
          "covering the full film production process from concept creation and
          screenwriting to planning and stage production"
        </h2>
      </section>
    </div>
  );
};

export default Homepage;
