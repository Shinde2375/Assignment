// src/Dashboard.js
import React, { useState } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import "./Dashboard.css"; // Ensure custom styles are created here

const Dashboard = () => {
  const { logout, user, isAuthenticated } = useAuth0();
  const [showProfile, setShowProfile] = useState(false);

  const toggleProfile = () => {
    setShowProfile((prev) => !prev);
  };

  // Check if the user is authenticated before rendering the dashboard
  if (!isAuthenticated) {
    
    return alert("Please log in to access the dashboard.");
    
  }

  return (
    <div className="dashboard-container">
      {/* Navbar */}
      <header className="navbarDashboard">
        <div className="logo">
          <img className="imglogo" src="dashboard_logo.png" alt="Logo" />
        </div>
        <h1 className="dashboard-title">Dashboard</h1>
        <div className="navbar-right">
          <button className="upgrade-button" onClick={() => alert("Upgrade Plan Feature Coming Soon")}>
            Upgrade your plan
          </button>
          <button className="new-project-button" onClick={() => alert("New Project Creation Coming Soon")}>
            + Start new project
          </button>

          {/* Profile Icon with Dropdown */}
          <div className="profile-icon-container">
            <img
              src={user.picture}
              alt="Profile Icon"
              className="profile-icon"
              onClick={toggleProfile}
            />
            {showProfile && (
              <div className="profile-dropdown">
                {/* <p>Name: {user.name}</p> */}
                <p>Email: {user.email}</p>
                <button
                  className="logout-button"
                  onClick={() => logout({ returnTo: window.location.origin })}
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="tabs">
        <button className="tab active">My Projects</button>
        <button className="tab active2">Shared with me</button>
      </div>

      {/* Information Cards */}
      <div className="cards-container">
        <div className="info-cards">
          <div className="card">
            <div className="card-icon">👍</div>
            <h3>Leave Feedback</h3>
            <p>Help us make NolanAI even better!</p>
            <button className="card-button" onClick={() => alert("Survey Coming Soon")}>
              Take Survey ➔
            </button>
          </div>
          <div className="card">
            <div className="card-icon">💬</div>
            <h3>Join us on Discord!</h3>
            <p>Check out our Discord page to be a part of the NolanAI community</p>
            <button className="card-button" onClick={() => alert("Discord Coming Soon")}>
              Join group ➔
            </button>
          </div>
        </div>
      </div>

      {/* Main Section */}
      <div className="main-section">
        <div className="start-project">
          <div className="folder-icon">📂</div>
          <h2>Start Your First Project</h2>
          <p>Every great story begins with a first scene. Start your project and set the stage—your work in progress will appear here.</p>
          <button className="start-project-button" onClick={() => alert("New Project Feature Coming Soon")}>
            + Start New Project
          </button>
        </div>
      </div>

    </div>
  );
};

export default Dashboard;
