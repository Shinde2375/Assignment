
import React from "react";

import './App.css';

import Homepage from './Components/Homepage';
import Dashboard from "./Components/Dashboard";
import { createBrowserRouter, RouterProvider } from "react-router-dom";


function App() {

  const router = createBrowserRouter([
    {
      path:"/",
      element:<> <Homepage /> </>,  
    },
    {
      path:"/Dashboard",
      element:<><Dashboard /></>,
    },
    {
      path:"/*",
      element:<><Homepage /></>,
    }
  ])
  return (
    <>
   
<RouterProvider router={router}/>
</>
 );
}

export default App;
